@echo off
echo Starting CampusPulse...
start "" "%~dp0index.html"
exit
